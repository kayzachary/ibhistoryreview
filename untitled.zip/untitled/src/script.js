const { useState, useEffect, useRef, useMemo } = React;

const ERA_SUMMARIES = {
  "Pre-Reform Era": {
    dates: "c1800 – 1839",
    overview: "The Ottoman Empire enters the 19th century under serious strain. Two reforming sultans — Selim III and Mahmud II — attempt to modernize the military, but face violent resistance from the Janissary corps. Meanwhile, the empire loses Greece after a decade of revolt, European naval intervention at Navarino, and Russian military pressure. At the same time, Muhammad Ali builds an autonomous Egyptian state, invades the Hejaz and Sudan, and twice humiliates the Ottoman army — coming close to toppling the empire entirely. France seizes Algeria. Russia extracts the Treaty of Unkiar Skelessi. The empire is visibly weakening.",
    keyThemes: ["Janissary resistance to reform", "Greek War of Independence", "Muhammad Ali's rise in Egypt", "Russian expansion southward", "European great-power intervention"],
    keyFigures: ["Selim III", "Mahmud II", "Muhammad Ali Pasha", "Ibrahim Pasha", "George Canning", "Nicholas I"],
    examTip: "Questions on this era often ask you to evaluate whether internal weakness or external pressure was the bigger challenge. Argue both — they reinforced each other."
  },
  "Reform & Decline": {
    dates: "1839 – 1876",
    overview: "The Tanzimat era opens with the Rescript of Rose Chamber (1839) and attempts sweeping modernization: legal equality for non-Muslims, railway and telegraph networks, a new army, secular schools, and a central bank. But reform comes with costs — foreign debt spirals, the Suez Canal construction bankrupts Egypt, and European creditors gain influence. The Crimean War (1854–56) temporarily shores up Ottoman prestige but deepens dependency on Western loans. Russia continues pressing in the Balkans, leading to the 1877 war and the humiliating Treaty of San Stefano — revised only by European intervention at the Congress of Berlin. Egypt slides toward British occupation.",
    keyThemes: ["Tanzimat modernization program", "Crimean War and Treaty of Paris", "Eastern Question diplomacy", "Egyptian debt and British encroachment", "Russo-Turkish rivalry in the Balkans"],
    keyFigures: ["Lord Palmerston", "Nicholas I", "Ahmed Arabi", "Tsar Alexander II"],
    examTip: "The Tanzimat is a favorite essay topic — always weigh its genuine achievements against its failure to prevent territorial loss and debt dependency."
  },
  "Hamidian Era": {
    dates: "1876 – 1908",
    overview: "Abdul Hamid II briefly grants a constitution and parliament in 1876, then suspends both in 1878 — ruling for 30 years through surveillance, censorship, and a vast spy network. He uses Pan-Islamic ideology to shore up legitimacy while selectively modernizing railways and communications. But the era is defined by catastrophe: the Armenian Massacres (1894–96) kill up to 300,000 and earn him the title 'the Red Sultan.' European creditors take direct control of Ottoman tax revenues through the Public Debt Administration. Libya's Senussi resistance grows. Italy seizes Libya in 1911. The empire's sovereignty is visibly eroding from every direction.",
    keyThemes: ["Autocratic rule and suspension of constitution", "Pan-Islamic ideology as political tool", "Armenian Massacres and international response", "European financial control via debt administration", "Loss of North Africa"],
    keyFigures: ["Abdul Hamid II", "Sayyid Muhammad Ali as-Senussi"],
    examTip: "Abdul Hamid is a classic IB question — was he a reformer or a reactionary? The best answers show he was both, selectively, and explain why that distinction matters."
  },
  "Young Turk Era": {
    dates: "1908 – 1914",
    overview: "The Committee of Union and Progress (CUP) forces the restoration of the 1876 constitution, then deposes Abdul Hamid entirely in 1909. Initial hopes for liberal reform quickly give way to authoritarian CUP rule under figures like Enver Bey. The empire suffers its worst territorial losses in the Balkan Wars (1912–13), losing nearly all of its remaining European territory to a coalition of smaller states. The shock of this catastrophe pushes the CUP toward German alliance and a more militaristic, nationalist direction — setting the stage for WWI entry. Sultan Mehmet V is a figurehead throughout.",
    keyThemes: ["CUP's revolutionary seizure of power", "Restoration and limits of constitutional government", "Balkan Wars and territorial catastrophe", "Shift toward German alliance", "Rising Turkish nationalism"],
    keyFigures: ["Enver Bey", "Mehmet V", "CUP leadership triumvirate"],
    examTip: "IB questions on the Young Turks often ask why they failed to reform the empire. Focus on the gap between their liberal promises and their increasingly authoritarian, nationalist practice."
  },
  "Collapse": {
    dates: "1914 – 1923",
    overview: "The Ottoman Empire enters WWI on the German side in late 1914. The war brings catastrophe on every front: the Gallipoli campaign (1915–16) is repelled but at enormous cost; the Caucasus offensive collapses and triggers the Armenian Genocide (1915); Arab forces under the Sharif of Mecca revolt with British support; British forces advance through Palestine and Mesopotamia. Defeat brings Allied occupation of Constantinople and the Treaty of Sèvres (1920), which dismembers the empire. But Kemal Ataturk leads a nationalist war of independence, defeats Greek forces in Anatolia, and secures the Treaty of Lausanne (1923) — ending the empire and founding the Republic of Turkey.",
    keyThemes: ["Ottoman entry and strategy in WWI", "Gallipoli and the war's military campaigns", "Armenian Genocide", "Arab Uprising and British promises", "Ataturk's nationalist revival and Treaty of Lausanne"],
    keyFigures: ["Kemal Ataturk", "Enver Bey", "Sharif of Mecca", "T.E. Lawrence"],
    examTip: "WWI questions often ask you to evaluate the reasons for Ottoman entry or the war's impact. Don't forget the Armenian Genocide and Arab Uprising as domestic consequences alongside military campaigns."
  }
};

const TERMS = [
  { name:"Selim III", definition:"Ottoman Sultan (1789–1807) who initiated the Nizam-i Cedid ('New Order') military reform program, only to be deposed and later killed in a Janissary revolt before his reforms could take hold.", period:"Pre-Reform Era", type:"Person", actor:"Ottoman", impact:"Political", hint:"His reform program was strangled by Janissary resistance — the same corps Mahmud II would later destroy in 1826." },
  { name:"Mahmud II", definition:"Ottoman Sultan (1808–1839) who destroyed the Janissary corps in the 'Auspicious Incident' of 1826, launched modernizing reforms, but lost Syria to Muhammad Ali and died as the empire appeared on the brink of collapse.", period:"Pre-Reform Era", type:"Person", actor:"Ottoman", impact:"Political", hint:"He destroyed the Janissaries in 1826 — but his reforms came too late to save Syria from Muhammad Ali." },
  { name:"Mamluks", definition:"The military slave caste that had dominated Egypt for centuries. Muhammad Ali lured their leaders to a banquet at Cairo's citadel in 1811 and had them massacred, ending their power and consolidating his own rule.", period:"Pre-Reform Era", type:"Concept/Group", actor:"Egypt/Muhammad Ali", impact:"Political", hint:"Their massacre was disguised as a banquet invitation — a trap set within the citadel walls." },
  { name:"Muhammad Ali Pasha", definition:"Albanian-born Ottoman governor of Egypt (1805–1848) who built a modernized army and bureaucracy, conquered Sudan and the Hejaz, challenged the Ottoman Empire twice, and is considered the founder of modern Egypt.", period:"Pre-Reform Era", type:"Person", actor:"Egypt/Muhammad Ali", impact:"Political", hint:"Though he nearly toppled the Ottoman Empire, European powers forced him to give up Syria — leaving him only hereditary rule over Egypt." },
  { name:"Invasion of the Hejaz 1811", definition:"Muhammad Ali's campaign into the Arabian Peninsula to crush the Wahhabi movement at the Ottoman sultan's request, securing the holy cities and establishing his military reputation beyond Egypt.", period:"Pre-Reform Era", type:"Crisis/Conflict", actor:"Egypt/Muhammad Ali", impact:"Military", hint:"He acted on behalf of the Ottoman sultan — this was his first major military commission outside Egypt." },
  { name:"Barbary Pirates", definition:"North African corsairs operating from Ottoman-controlled ports who preyed on Mediterranean shipping, prompting the First and Second Barbary Wars with the United States and eventually providing France a pretext for invading Algeria in 1830.", period:"Pre-Reform Era", type:"Concept/Group", actor:"Ottoman", impact:"Military", hint:"An unpaid debt from the Napoleonic era gave France its formal justification for invading Algeria." },
  { name:"Greek Revolt 1821", definition:"The Greek uprising against Ottoman rule beginning in 1821, initially in the Danubian principalities then spreading to the Peloponnese, ultimately producing an independent Greek state with European great-power support.", period:"Pre-Reform Era", type:"Crisis/Conflict", actor:"Greece/Balkans", impact:"Territorial", hint:"The uprising began in Moldavia and Wallachia before finding its footing in the Peloponnese." },
  { name:"Invasion of Sudan 1821", definition:"Muhammad Ali's conquest of Sudan to secure gold, ivory, and enslaved soldiers for his modernized army, significantly expanding Egyptian territory southward along the Nile.", period:"Pre-Reform Era", type:"Crisis/Conflict", actor:"Egypt/Muhammad Ali", impact:"Territorial", hint:"He was partly motivated by wanting enslaved Sudanese soldiers for his new-model military." },
  { name:"Ibrahim Pasha", definition:"Son of Muhammad Ali who led Egyptian forces to brutally suppress the Greek revolt on behalf of the Ottomans, then commanded the armies that crushed the Ottomans in both Eastern Mediterranean Crises, advancing to within striking distance of Constantinople.", period:"Pre-Reform Era", type:"Person", actor:"Egypt/Muhammad Ali", impact:"Military", hint:"His harsh campaign in the Peloponnese alarmed European powers and accelerated their intervention at Navarino." },
  { name:"George Canning", definition:"British Foreign Secretary and Prime Minister who broke from the conservative Concert of Europe to support Greek independence, co-sponsoring the Treaty of London 1827 — but died the same year before seeing its results.", period:"Pre-Reform Era", type:"Person", actor:"Britain", impact:"Diplomatic", hint:"He died in 1827 — the same year the Treaty of London and Battle of Navarino he set in motion both occurred." },
  { name:"Treaty of London 1827", definition:"Agreement between Britain, France, and Russia demanding an armistice in Greece; Ottoman refusal gave the allied fleet its justification for direct naval intervention at Navarino Bay.", period:"Pre-Reform Era", type:"Treaty/Agreement", actor:"Multi-European", impact:"Diplomatic", hint:"The Ottomans refused the armistice — which gave the allied fleet its legal cover for Navarino." },
  { name:"Battle of Navarino Bay", definition:"The decisive October 1827 naval battle in which the combined British, French, and Russian fleets destroyed the Ottoman-Egyptian fleet, making Greek independence effectively inevitable.", period:"Pre-Reform Era", type:"Battle/Military Action", actor:"Multi-European", impact:"Military", hint:"The last major fleet battle fought entirely by sailing ships; a British admiral later called it an 'untoward event.'" },
  { name:"Russo-Turkish War 1828-29", definition:"War launched after Ottoman refusal of London Treaty terms; Russian forces drove deep into the Balkans and Anatolia, forcing a humiliating Ottoman defeat that exposed the empire's military weakness.", period:"Pre-Reform Era", type:"Crisis/Conflict", actor:"Russia", impact:"Military", hint:"Russian forces advanced close enough to Constantinople to alarm Britain far more than the Ottoman losses did." },
  { name:"Treaty of Adrianople 1829", definition:"The peace settlement ending the Russo-Turkish War, granting Russia control of the Danube delta and eastern Black Sea coast while requiring Ottoman recognition of Greek autonomy.", period:"Pre-Reform Era", type:"Treaty/Agreement", actor:"Russia", impact:"Territorial", hint:"Russia gained the Danube delta and much of the eastern Black Sea coast — a major strategic expansion." },
  { name:"French Invasion of Algeria", definition:"France's 1830 invasion and colonization of Algeria, using piracy disputes and a diplomatic insult as pretexts, removing a nominally Ottoman territory and setting a precedent for European seizure of North African lands.", period:"Pre-Reform Era", type:"Crisis/Conflict", actor:"France", impact:"Territorial", hint:"The pretext was an Ottoman official striking the French consul with a fly whisk during a debt dispute." },
  { name:"London Protocol 1830", definition:"The agreement formally upgrading Greece from autonomous to fully independent, recognized by all major European powers as a sovereign state — a direct territorial loss for the Ottoman Empire.", period:"Pre-Reform Era", type:"Treaty/Agreement", actor:"Multi-European", impact:"Territorial", hint:"This upgraded Greece's status from 'autonomous' to a fully recognized independent state." },
  { name:"First Eastern Mediterranean Crisis 1832", definition:"The crisis in which Muhammad Ali's forces invaded Syria and crushed the Ottoman army at Konya, advancing on Constantinople itself until Russian intervention forced a halt and produced the Treaty of Unkiar Skelessi.", period:"Pre-Reform Era", type:"Crisis/Conflict", actor:"Egypt/Muhammad Ali", impact:"Military", hint:"The Ottoman defeat was so total that Russia sent troops to defend Constantinople — alarming Britain enormously." },
  { name:"Treaty of Unkiar Skelessi 1833", definition:"A defensive alliance between Russia and the Ottoman Empire that secretly granted Russia the right to send warships through the Bosphorus Straits, effectively making the Ottomans a Russian protectorate.", period:"Pre-Reform Era", type:"Treaty/Agreement", actor:"Russia", impact:"Diplomatic", hint:"Britain was furious — it appeared Russia had won dominant strategic control over Constantinople itself." },
  { name:"Lord Palmerston", definition:"British Foreign Secretary who orchestrated the European coalition against Muhammad Ali in 1839-40, fearing a powerful Egypt would threaten British trade routes to India and tip the Eastern Mediterranean toward France.", period:"Reform & Decline", type:"Person", actor:"Britain", impact:"Diplomatic", hint:"He feared a strong Muhammad Ali more than the weakened Ottomans — and deliberately excluded France from the coalition." },
  { name:"Second Eastern Mediterranean Crisis 1839", definition:"The renewed conflict in which Egyptian forces again defeated the Ottomans; the Ottoman fleet defected to Muhammad Ali and the Sultan died in the same week, leaving the empire on the verge of total collapse.", period:"Reform & Decline", type:"Crisis/Conflict", actor:"Egypt/Muhammad Ali", impact:"Military", hint:"In one catastrophic week: Ottoman army defeated, Ottoman fleet defected, Sultan died." },
  { name:"Rescript of Rose Chamber 1839", definition:"The Gulhane Edict launching the Tanzimat era, promising Ottoman subjects equality before the law regardless of religion, security of life and property, and an end to tax farming.", period:"Reform & Decline", type:"Document", actor:"Ottoman", impact:"Political", hint:"Issued at the Rose Chamber of Topkapi Palace, it promised equal rights to Muslim and non-Muslim subjects alike." },
  { name:"London Convention 1840", definition:"Agreement by Britain, Austria, Prussia, and Russia (excluding France) to force Muhammad Ali from Syria, offering him only hereditary rule over Egypt — reversing his empire-building and isolating France diplomatically.", period:"Reform & Decline", type:"Treaty/Agreement", actor:"Multi-European", impact:"Diplomatic", hint:"France's exclusion punished it for backing Muhammad Ali — isolating both Paris and Cairo simultaneously." },
  { name:"British Bombing of Beirut 1840", definition:"The Royal Navy's bombardment of Beirut combined with local Syrian uprisings to rapidly unravel Egyptian control over the Levant, forcing Muhammad Ali's withdrawal from Syria.", period:"Reform & Decline", type:"Battle/Military Action", actor:"Britain", impact:"Military", hint:"Local Syrian resistance and British naval power combined to collapse Egyptian control with surprising speed." },
  { name:"Straits Convention 1841", definition:"An international agreement closing the Bosphorus and Dardanelles to warships of all nations in peacetime, replacing the bilateral Unkiar Skelessi treaty and stripping Russia of its special strategic position.", period:"Reform & Decline", type:"Treaty/Agreement", actor:"Multi-European", impact:"Diplomatic", hint:"Britain's great diplomatic triumph — it reversed Russia's strategic advantage won at Unkiar Skelessi." },
  { name:"Eastern Question", definition:"The diplomatic problem posed to European powers by the gradual weakening of the Ottoman Empire — who would inherit its territories and influence, and how could a catastrophic war among the powers be avoided?", period:"Reform & Decline", type:"Concept/Group", actor:"Multi-European", impact:"Diplomatic", hint:"It was never truly 'answered' — it drove European diplomacy from the 1820s through WWI." },
  { name:"Nicholas I", definition:"Russian Tsar (1825-1855) who aggressively pursued Russian interests in Ottoman territories, reportedly coined the phrase 'Sick Man of Europe,' and whose ambitions in the Holy Land directly triggered the Crimean War.", period:"Reform & Decline", type:"Person", actor:"Russia", impact:"Political", hint:"He reportedly used the phrase 'Sick Man of Europe' in conversation with the British ambassador in 1853." },
  { name:"Tanzimat Reforms", definition:"The sweeping Ottoman modernization program (1839-1876) that reorganized the army, created new legal codes, established secular schools, built railways and telegraphs, and extended formal equality to non-Muslim subjects.", period:"Reform & Decline", type:"Policy/Reform", actor:"Ottoman", impact:"Social/Cultural", hint:"'Tanzimat' means 'reorganization' — it touched everything from the army to property law to the telegraph network." },
  { name:"Battle of Sinope 1853", definition:"A Russian naval attack destroying an Ottoman frigate squadron at Sinope, inflaming British and French public opinion and accelerating their entry into what became the Crimean War.", period:"Reform & Decline", type:"Battle/Military Action", actor:"Russia", impact:"Military", hint:"The Western press called it the 'Sinope Massacre' — public outrage pushed Britain and France toward war." },
  { name:"Crimean War 1854-56", definition:"The war pitting Britain, France, and the Ottomans against Russia, fought primarily in Crimea. It checked Russian expansion and produced the Treaty of Paris which admitted the empire to the Concert of Europe.", period:"Reform & Decline", type:"Crisis/Conflict", actor:"Multi-European", impact:"Military", hint:"The war that made Florence Nightingale famous — nursing reforms emerged directly from its catastrophic casualty rates." },
  { name:"Treaty of Paris 1856", definition:"The peace settlement ending the Crimean War that checked Russian power, nominally guaranteed Ottoman territorial integrity, and formally admitted the Ottoman Empire as a member of the Concert of Europe.", period:"Reform & Decline", type:"Treaty/Agreement", actor:"Multi-European", impact:"Diplomatic", hint:"The treaty admitted the Ottoman Empire to the Concert of Europe — briefly legitimizing it as a great power." },
  { name:"Hatt-i Humayun 1856", definition:"An imperial edict extending and strengthening Tanzimat reforms, explicitly guaranteeing equal rights for non-Muslim subjects in response to pressure from Britain and France as Crimean War allies.", period:"Reform & Decline", type:"Document", actor:"Ottoman", impact:"Social/Cultural", hint:"Issued partly under British and French pressure — the Ottomans' Crimean allies wanted proof of liberal reform." },
  { name:"Lebanese Civil War 1860", definition:"Sectarian conflict between Maronite Christians and Druze in Mount Lebanon, fueled by economic inequality and competing British/French patronage, resulting in French intervention and a new autonomous arrangement for the region.", period:"Reform & Decline", type:"Crisis/Conflict", actor:"Multi-European", impact:"Political", hint:"French traders had enriched Maronite merchants; British influence backed the Druze — European rivalry fueled the fire." },
  { name:"Suez Canal", definition:"The waterway connecting the Mediterranean to the Red Sea, completed in 1869. Egypt incurred massive debt financing it; Britain purchased Egypt's shares in 1875 and eventually invaded to protect its investment.", period:"Reform & Decline", type:"Policy/Reform", actor:"Egypt/Muhammad Ali", impact:"Territorial", hint:"Britain's purchase of Egypt's shares in 1875 was the first step toward its occupation of Egypt seven years later." },
  { name:"Ahmed Arabi", definition:"Egyptian army officer and nationalist leader who led the 1881-82 revolt against Khedive Tewfik and European financial control, prompting the British military intervention that began Egypt's de facto occupation.", period:"Reform & Decline", type:"Person", actor:"Arab/Nationalist", impact:"Political", hint:"His revolt forced Britain's hand — London invaded partly to crush him and protect the Suez Canal investment." },
  { name:"British Invasion of Egypt 1882", definition:"The British military occupation of Egypt following Ahmed Arabi's nationalist revolt, begun under the pretext of protecting European investments and the Suez Canal and lasting until 1956.", period:"Reform & Decline", type:"Battle/Military Action", actor:"Britain", impact:"Territorial", hint:"Britain intended it as a temporary measure — it lasted 74 years." },
  { name:"Russo-Turkish War 1877", definition:"Russia's war against the Ottomans in support of Balkan nationalist uprisings, resulting in sweeping Russian victories that threatened Constantinople itself before European powers forced a negotiation.", period:"Reform & Decline", type:"Crisis/Conflict", actor:"Russia", impact:"Military", hint:"Russia came so close to Constantinople that Britain sent a fleet through the Straits to warn them off." },
  { name:"Treaty of San Stefano", definition:"The post-war settlement imposed by Russia in 1878, creating a large autonomous Bulgaria as a Russian client state — so threatening to European interests that Britain and Austria forced an immediate revision.", period:"Reform & Decline", type:"Treaty/Agreement", actor:"Russia", impact:"Territorial", hint:"The 'Big Bulgaria' it created would have given Russia a client state stretching to the Aegean Sea." },
  { name:"Congress of Berlin", definition:"The 1878 conference of European powers that revised the Treaty of San Stefano, reducing Bulgaria's size, recognizing new Balkan states, and awarding Britain Cyprus and Austria Bosnia.", period:"Reform & Decline", type:"Treaty/Agreement", actor:"Multi-European", impact:"Diplomatic", hint:"Bismarck acted as the 'honest broker' — but Russia felt cheated of the fruits of its military victory." },
  { name:"Sick Man of Europe", definition:"Nicholas I's phrase describing the Ottoman Empire as a dying power whose collapse would create a dangerous scramble among European states — encapsulating the Eastern Question in a single image.", period:"Reform & Decline", type:"Concept/Group", actor:"Ottoman", impact:"Political", hint:"Nicholas I used this phrase with the British ambassador in 1853 — trying to discuss how to divide the inheritance." },
  { name:"French Influence in Egypt", definition:"France's cultural, military, and educational role as Muhammad Ali's primary modernization model — French officers trained his army, French engineers built infrastructure, and French schools educated Egypt's new elite.", period:"Reform & Decline", type:"Concept/Group", actor:"Egypt/Muhammad Ali", impact:"Social/Cultural", hint:"Muhammad Ali sent Egyptian students to Paris and hired French officers to train his new-model army." },
  { name:"Abdul Hamid II", definition:"Ottoman Sultan (1876-1909) who briefly established a constitutional government then suspended it for 30 years, ruling through surveillance and repression while selectively modernizing the empire.", period:"Hamidian Era", type:"Person", actor:"Ottoman", impact:"Political", hint:"He built an extensive spy network and used the telegraph to monitor the empire — but was finally deposed by the Young Turks in 1909." },
  { name:"Constitutional Era 1876", definition:"The brief period in which Abdul Hamid granted a constitution and convened an Ottoman parliament, only to suspend both in 1878 using the Russo-Turkish War as a pretext — ruling as an autocrat for the next 30 years.", period:"Hamidian Era", type:"Policy/Reform", actor:"Ottoman", impact:"Political", hint:"He convened parliament partly to impress European powers at the 1876 Constantinople Conference — then shut it down." },
  { name:"Senussi Movement", definition:"A Sufi Islamic order founded in Libya by Sayyid Muhammad Ali as-Senussi that became the primary force of resistance to both Ottoman weakness and eventual Italian colonization in Tripolitania.", period:"Hamidian Era", type:"Concept/Group", actor:"Arab/Nationalist", impact:"Political", hint:"They built an extensive network of lodges across the Sahara, providing education, justice, and eventually military resistance." },
  { name:"Armenian Massacres 1894-96", definition:"A series of massacres of Armenian populations across the Ottoman Empire under Abdul Hamid II, killing an estimated 100,000-300,000 people and drawing international condemnation while European powers failed to intervene.", period:"Hamidian Era", type:"Crisis/Conflict", actor:"Ottoman", impact:"Social/Cultural", hint:"European powers threatened intervention but ultimately did nothing — earning Abdul Hamid the epithet 'the Red Sultan.'" },
  { name:"Ottoman Public Debt Administration", definition:"The 1881 institution giving European creditors direct control over key Ottoman tax revenues after the empire defaulted on its debts, representing a severe loss of financial sovereignty to foreign powers.", period:"Hamidian Era", type:"Policy/Reform", actor:"Multi-European", impact:"Political", hint:"European bankers collected Ottoman tobacco, salt, silk, and stamp taxes directly — the empire could not touch them." },
  { name:"Italo-Turkish War 1911-12", definition:"Italy's war to seize Libya from the Ottomans — the empire's first modern colonial loss in Africa, which also exposed Ottoman military weakness just before the Balkan Wars.", period:"Hamidian Era", type:"Crisis/Conflict", actor:"Italy", impact:"Territorial", hint:"Italy used aerial bombing for the first time in the history of warfare during this conflict." },
  { name:"Committee of Union and Progress", definition:"The Young Turk organization that restored the Ottoman constitution in 1908, deposed Abdul Hamid in 1909, and increasingly dominated government — ultimately leading the empire into WWI as a German ally.", period:"Young Turk Era", type:"Concept/Group", actor:"Young Turks/CUP", impact:"Political", hint:"Known by its French acronym 'CUP' — it went from a secret revolutionary society to the empire's ruling faction in months." },
  { name:"Enver Bey", definition:"Young Turk military officer and CUP leader who led the 1913 coup that made the CUP dominant, then engineered the Ottoman alliance with Germany and commanded disastrous campaigns in WWI.", period:"Young Turk Era", type:"Person", actor:"Young Turks/CUP", impact:"Political", hint:"His reckless Caucasus offensive in winter 1914-15 destroyed three Ottoman corps and helped trigger the Armenian Genocide." },
  { name:"Mehmet V", definition:"Ottoman Sultan (1909-1918) installed by the Young Turks after Abdul Hamid's deposition; a figurehead with little real power while the CUP effectively governed the empire through WWI.", period:"Young Turk Era", type:"Person", actor:"Ottoman", impact:"Political", hint:"He was 64 when enthroned and largely ceremonial — real power lay with the CUP's ruling triumvirate." },
  { name:"Balkan Wars 1912-13", definition:"Two rapid wars in which Balkan states stripped the Ottoman Empire of nearly all its remaining European territory in the First War, then fought each other over the spoils in the Second.", period:"Young Turk Era", type:"Crisis/Conflict", actor:"Greece/Balkans", impact:"Territorial", hint:"The empire lost nearly all of its European territory in months — only a sliver around Edirne remained." },
  { name:"Gallipoli Campaign", definition:"The 1915-16 Allied operation to knock the Ottomans out of WWI by seizing the Dardanelles and Constantinople, repelled by Ottoman forces in a costly failure that made Mustafa Kemal's reputation.", period:"Collapse", type:"Battle/Military Action", actor:"Multi-European", impact:"Military", hint:"The Allied failure at Gallipoli launched Ataturk's legend — and ended Churchill's political career for years." },
  { name:"Arab Uprising", definition:"The 1916 revolt of Arab leaders against Ottoman rule, coordinated with Britain via the Sharif of Mecca, which opened a second front and accelerated the empire's collapse in the Middle East.", period:"Collapse", type:"Crisis/Conflict", actor:"Arab/Nationalist", impact:"Political", hint:"T.E. Lawrence ('Lawrence of Arabia') coordinated British support for the Arab revolt in the Hejaz." },
  { name:"Armenian Genocide", definition:"The systematic deportation and mass killing of approximately 1-1.5 million Armenians by the Ottoman government beginning in 1915, carried out under wartime conditions as a deliberate policy of the CUP leadership.", period:"Collapse", type:"Crisis/Conflict", actor:"Ottoman", impact:"Social/Cultural", hint:"The deportation orders came from Enver Bey's interior ministry — death marches through the Syrian desert were the primary method." },
  { name:"Kemal Ataturk", definition:"Ottoman general who defended Gallipoli, led the Turkish nationalist movement after WWI, won the War of Independence against Greek forces, abolished the Ottoman sultanate, and founded the secular Turkish Republic in 1923.", period:"Collapse", type:"Person", actor:"Young Turks/CUP", impact:"Political", hint:"He told his troops at Gallipoli: 'I am not ordering you to attack. I am ordering you to die.'" },
  { name:"Partitioning of the Empire", definition:"The post-WWI Allied division of Ottoman territories under League of Nations mandates — Britain took Palestine, Iraq, and Transjordan; France took Syria and Lebanon — replacing Ottoman rule with European imperial control.", period:"Collapse", type:"Treaty/Agreement", actor:"Multi-European", impact:"Territorial", hint:"The secret Sykes-Picot Agreement of 1916 had already divided the Middle East between Britain and France before the war ended." },
  { name:"Treaty of Lausanne", definition:"The 1923 treaty that formally recognized the Republic of Turkey's borders after the War of Independence, replacing the humiliating Treaty of Sevres and marking the final end of the Ottoman Empire.", period:"Collapse", type:"Treaty/Agreement", actor:"Multi-European", impact:"Territorial", hint:"It also formalized a massive population exchange between Greece and Turkey — one of history's first modern ethnic transfers." },
];

const PERIOD_ORDER = ["Pre-Reform Era","Reform & Decline","Hamidian Era","Young Turk Era","Collapse"];
const TYPE_GROUPS = {"Person":"human","Battle/Military Action":"military","Crisis/Conflict":"military","Treaty/Agreement":"document","Document":"document","Policy/Reform":"document","Concept/Group":"idea"};
const ACTOR_GROUPS = {"Ottoman":"empire","Egypt/Muhammad Ali":"empire","Young Turks/CUP":"empire","Britain":"western","France":"western","Multi-European":"western","Italy":"western","Russia":"eastern","Greece/Balkans":"eastern","Arab/Nationalist":"resistance"};
const IMPACT_GROUPS = {"Military":"force","Territorial":"force","Diplomatic":"order","Political":"order","Social/Cultural":"society"};

function compare(guess, target) {
  var pI = PERIOD_ORDER.indexOf(guess.period), pJ = PERIOD_ORDER.indexOf(target.period);
  return {
    period: { result: guess.period===target.period?"match":Math.abs(pI-pJ)===1?"close":"miss", label:guess.period, dir: guess.period!==target.period?(pI<pJ?"later":"earlier"):"" },
    type:   { result: guess.type===target.type?"match":TYPE_GROUPS[guess.type]===TYPE_GROUPS[target.type]?"close":"miss", label:guess.type },
    actor:  { result: guess.actor===target.actor?"match":ACTOR_GROUPS[guess.actor]===ACTOR_GROUPS[target.actor]?"close":"miss", label:guess.actor },
    impact: { result: guess.impact===target.impact?"match":IMPACT_GROUPS[guess.impact]===IMPACT_GROUPS[target.impact]?"close":"miss", label:guess.impact },
  };
}

function matchScore(c) {
  return ["period","type","actor","impact"].filter(function(k){return c[k].result==="match";}).length;
}

function getRandomTerm(excludeName) {
  var pool = TERMS.filter(function(t){ return t.name !== excludeName; });
  return pool[Math.floor(Math.random() * pool.length)];
}

var CSS = '\
@import url("https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Cinzel:wght@400;600;800&display=swap");\
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}\
:root{\
  --parch:#f5edd8;--parch2:#ede0c4;--sand:#d4b483;\
  --gold:#b8860b;--gold2:#d4a017;\
  --match-bg:#1e3a2a;--match-border:#2d7a50;--match-text:#6ec48a;--match-label:#3a9060;\
  --close-bg:#3a2a0a;--close-border:#8b6010;--close-text:#d4a030;--close-label:#a07820;\
  --miss-bg:#2a0a0a;--miss-border:#7a2020;--miss-text:#c85050;--miss-label:#8a3030;\
}\
body{background:#0e0a05}\
.wrap{min-height:100vh;background:linear-gradient(160deg,#0e0a05 0%,#1a1008 50%,#0e0a05 100%);font-family:"Cormorant Garamond",Georgia,serif;color:var(--parch);padding-bottom:80px}\
.bg-scroll{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none}\
.bg-col{position:absolute;top:0;display:flex;flex-direction:column;gap:32px;animation:scrollUp linear infinite;opacity:0.07}\
.bg-col:nth-child(1){left:1%;animation-duration:40s;font-size:.8rem}\
.bg-col:nth-child(2){left:21%;animation-duration:55s;font-size:1.3rem}\
.bg-col:nth-child(3){left:42%;animation-duration:47s;font-size:.65rem}\
.bg-col:nth-child(4){left:62%;animation-duration:62s;font-size:1rem}\
.bg-col:nth-child(5){left:80%;animation-duration:36s;font-size:.9rem}\
.bg-term{font-family:"Cinzel",serif;color:var(--gold);white-space:nowrap;letter-spacing:.08em;display:block}\
@keyframes scrollUp{from{transform:translateY(0)}to{transform:translateY(-50%)}}\
.wrap>*:not(.bg-scroll){position:relative;z-index:1}\
.header{text-align:center;padding:28px 20px 18px}\
.hline{height:1px;background:linear-gradient(90deg,transparent,var(--gold),var(--gold2),var(--gold),transparent)}\
.hline.top{margin-bottom:14px}.hline.bot{margin-top:14px}\
.title{font-family:"Cinzel",serif;font-size:2.6rem;font-weight:800;letter-spacing:.3em;color:var(--gold2);text-shadow:0 0 40px rgba(212,160,23,.25)}\
.subtitle{font-size:.82rem;letter-spacing:.25em;text-transform:uppercase;color:var(--sand);opacity:.7;margin-top:4px}\
.unit-tag{font-size:.7rem;letter-spacing:.13em;color:var(--gold);opacity:.4;margin-top:3px;text-transform:uppercase}\
.top-bar{display:flex;justify-content:center;align-items:center;gap:10px;padding:10px 20px;border-bottom:1px solid rgba(180,130,60,.12);flex-wrap:wrap}\
.mode-btn{font-family:"Cinzel",serif;font-size:.72rem;letter-spacing:.13em;text-transform:uppercase;padding:6px 14px;border-radius:2px;border:1px solid rgba(180,130,60,.25);background:transparent;color:rgba(212,176,120,.5);cursor:pointer;transition:all .2s}\
.mode-btn:hover{border-color:var(--gold2);color:var(--gold2)}\
.mode-btn.active{background:rgba(180,130,60,.12);border-color:var(--gold2);color:var(--gold2)}\
.new-btn{font-family:"Cinzel",serif;font-size:.72rem;letter-spacing:.13em;text-transform:uppercase;padding:6px 16px;border-radius:2px;border:1px solid var(--gold);background:rgba(180,130,60,.15);color:var(--gold2);cursor:pointer;transition:all .2s;font-weight:600}\
.new-btn:hover{background:rgba(180,130,60,.28)}\
.period-bar{display:flex;justify-content:center;padding:8px 20px 0;flex-wrap:wrap;max-width:800px;margin:0 auto}\
.pl-item{font-size:.62rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(180,130,60,.45);padding:4px 10px;border-right:1px solid rgba(180,130,60,.1);cursor:pointer;transition:color .2s,background .2s;border-radius:2px}\
.pl-item:last-child{border-right:none}\
.pl-item:hover{color:var(--gold2)}\
.pl-item.era-active{color:var(--gold2);background:rgba(180,130,60,.1)}\
.era-modal-overlay{position:fixed;inset:0;z-index:500;background:rgba(0,0,0,.75);display:flex;align-items:center;justify-content:center;padding:20px;animation:fadeIn .2s ease}\
@keyframes fadeIn{from{opacity:0}to{opacity:1}}\
.era-modal{background:linear-gradient(160deg,#1e1508,#120e04);border:1px solid rgba(180,130,60,.35);border-radius:4px;max-width:620px;width:100%;max-height:85vh;overflow-y:auto;padding:28px;position:relative;box-shadow:0 24px 80px rgba(0,0,0,.9)}\
.era-modal::-webkit-scrollbar{width:4px}\
.era-modal::-webkit-scrollbar-thumb{background:rgba(180,130,60,.25);border-radius:2px}\
.era-close{position:absolute;top:14px;right:16px;font-family:"Cinzel",serif;font-size:.75rem;letter-spacing:.12em;text-transform:uppercase;color:rgba(180,130,60,.45);cursor:pointer;border:1px solid rgba(180,130,60,.2);background:transparent;padding:4px 10px;border-radius:2px;transition:all .2s}\
.era-close:hover{color:var(--gold2);border-color:var(--gold2)}\
.era-title{font-family:"Cinzel",serif;font-size:1.5rem;font-weight:800;color:var(--gold2);letter-spacing:.1em;margin-bottom:3px}\
.era-dates{font-size:.78rem;letter-spacing:.18em;text-transform:uppercase;color:var(--sand);opacity:.55;margin-bottom:16px}\
.era-divider{height:1px;background:linear-gradient(90deg,transparent,var(--gold),transparent);margin:14px 0}\
.era-overview{font-size:1rem;line-height:1.75;color:var(--parch);opacity:.9;margin-bottom:14px}\
.era-section-label{font-size:.65rem;letter-spacing:.22em;text-transform:uppercase;color:var(--gold);opacity:.6;margin-bottom:8px;margin-top:14px}\
.era-themes{display:flex;flex-direction:column;gap:5px}\
.era-theme{font-size:.88rem;color:var(--sand);padding-left:12px;position:relative;line-height:1.4}\
.era-theme::before{content:"—";position:absolute;left:0;color:var(--gold);opacity:.5}\
.era-figures{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}\
.era-figure{font-family:"Cinzel",serif;font-size:.72rem;letter-spacing:.08em;color:var(--gold2);background:rgba(180,130,60,.1);border:1px solid rgba(180,130,60,.25);border-radius:2px;padding:3px 9px}\
.era-exam{background:rgba(30,58,42,.3);border:1px solid rgba(45,122,80,.3);border-radius:3px;padding:12px 14px;margin-top:14px}\
.era-exam-label{font-size:.62rem;letter-spacing:.18em;text-transform:uppercase;color:var(--match-label);margin-bottom:5px}\
.era-exam-text{font-size:.9rem;font-style:italic;color:var(--sand);line-height:1.6;opacity:.9}\
.mystery-area{text-align:center;padding:16px 20px 8px}\
.mystery-label{font-size:.68rem;letter-spacing:.28em;text-transform:uppercase;color:var(--sand);opacity:.4;margin-bottom:10px}\
.mystery-box{display:inline-flex;gap:4px;flex-wrap:wrap;justify-content:center;padding:12px 24px;background:rgba(180,130,60,.04);border:1px solid rgba(180,130,60,.12);border-radius:2px;max-width:380px}\
.mystery-dot{width:11px;height:11px;border-radius:1px;background:rgba(180,130,60,.18);flex-shrink:0;transform:rotate(45deg);transition:background .4s,box-shadow .4s}\
.mystery-dot.lit{background:var(--gold2);box-shadow:0 0 6px rgba(212,160,23,.4)}\
.mystery-solved{font-family:"Cinzel",serif;font-size:1.7rem;font-weight:700;color:var(--gold2);letter-spacing:.08em}\
.mystery-def{font-style:italic;color:var(--sand);font-size:.95rem;max-width:540px;margin:8px auto 0;line-height:1.6;opacity:.85}\
.guess-counter{margin-top:8px;font-size:.75rem;color:var(--sand);letter-spacing:.1em;opacity:.4}\
.win-banner{text-align:center;padding:12px 20px;background:linear-gradient(135deg,rgba(30,58,42,.6),rgba(14,10,5,.8));border-top:1px solid var(--match-border);border-bottom:1px solid var(--match-border);margin:8px 0}\
.win-text{font-family:"Cinzel",serif;font-size:1.3rem;color:var(--match-text);letter-spacing:.15em}\
.win-sub{font-size:.82rem;color:var(--match-label);margin-top:3px;letter-spacing:.1em}\
.win-again{font-family:"Cinzel",serif;font-size:.75rem;letter-spacing:.14em;text-transform:uppercase;padding:7px 20px;border-radius:2px;border:none;background:linear-gradient(135deg,var(--gold),var(--gold2));color:#0e0a05;cursor:pointer;font-weight:700;margin-top:10px;transition:opacity .2s}\
.win-again:hover{opacity:.85}\
.hint-area{text-align:center;padding:0 20px 8px}\
.hint-btn{font-family:"Cinzel",serif;font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;padding:5px 14px;border-radius:2px;border:1px solid rgba(180,130,60,.2);background:transparent;color:rgba(180,130,60,.4);cursor:pointer;transition:all .2s}\
.hint-btn:hover:not(:disabled){border-color:var(--gold);color:var(--gold)}\
.hint-btn:disabled{opacity:.2;cursor:default}\
.hint-text{margin-top:6px;font-style:italic;color:var(--sand);font-size:.9rem;opacity:.75;max-width:500px;margin-left:auto;margin-right:auto;line-height:1.5}\
.game-columns{display:grid;grid-template-columns:1fr 1fr;gap:0;max-width:960px;margin:12px auto 0;padding:0 16px;align-items:start}\
.left-col{padding-right:16px;border-right:1px solid rgba(180,130,60,.1)}\
.right-col{padding-left:16px;max-height:520px;overflow-y:auto}\
.right-col::-webkit-scrollbar{width:4px}\
.right-col::-webkit-scrollbar-track{background:transparent}\
.right-col::-webkit-scrollbar-thumb{background:rgba(180,130,60,.2);border-radius:2px}\
.col-label{font-size:.62rem;letter-spacing:.2em;text-transform:uppercase;color:rgba(180,130,60,.3);margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid rgba(180,130,60,.08)}\
.search-wrap{position:relative}\
.search-row{display:flex;gap:8px;margin-bottom:4px}\
.search-input{flex:1;font-family:"Cormorant Garamond",serif;font-size:1.05rem;background:rgba(20,14,4,.85);border:1px solid rgba(180,130,60,.35);border-radius:2px;padding:10px 14px;color:var(--parch);outline:none;transition:border-color .2s}\
.search-input:focus{border-color:var(--gold2);background:rgba(30,20,6,.95)}\
.search-input::placeholder{color:rgba(180,130,60,.35)}\
.guess-btn{font-family:"Cinzel",serif;font-size:.78rem;letter-spacing:.1em;padding:10px 16px;background:linear-gradient(135deg,var(--gold),var(--gold2));border:none;border-radius:2px;color:#0e0a05;cursor:pointer;font-weight:700;transition:opacity .2s;white-space:nowrap}\
.guess-btn:hover:not(:disabled){opacity:.85}\
.guess-btn:disabled{opacity:.3;cursor:default}\
.dropdown{position:absolute;top:100%;left:0;right:0;background:#261a06;border:1px solid rgba(180,130,60,.55);border-top:none;border-radius:0 0 4px 4px;z-index:200;overflow:hidden;box-shadow:0 16px 48px rgba(0,0,0,.95)}\
.drop-item{padding:10px 14px;cursor:pointer;border-bottom:1px solid rgba(180,130,60,.1);transition:background .15s}\
.drop-item:last-child{border-bottom:none}\
.drop-item:hover{background:rgba(180,130,60,.14)}\
.drop-name{color:#fff;font-size:1rem;font-weight:600;font-family:"Cinzel",serif}\
.drop-meta{font-size:.75rem;color:var(--sand);margin-top:2px;opacity:.9}\
.legend{display:flex;gap:14px;flex-wrap:wrap;margin-top:14px}\
.leg-item{display:flex;align-items:center;gap:5px;font-size:.68rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(180,130,60,.45)}\
.leg-dot{width:9px;height:9px;border-radius:1px;transform:rotate(45deg);flex-shrink:0}\
.leg-dot.match{background:var(--match-text)}\
.leg-dot.close{background:var(--close-text)}\
.leg-dot.miss{background:var(--miss-text)}\
.no-guesses{font-style:italic;color:rgba(180,130,60,.25);font-size:.88rem;margin-top:8px}\
.guess-card{background:rgba(10,7,2,.6);border:1px solid rgba(180,130,60,.16);border-radius:2px;padding:10px 12px;margin-bottom:8px;animation:slideIn .25s ease}\
@keyframes slideIn{from{opacity:0;transform:translateX(8px)}to{opacity:1;transform:translateX(0)}}\
.guess-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;gap:6px}\
.guess-name{font-family:"Cinzel",serif;font-size:.88rem;font-weight:600;color:var(--parch2);letter-spacing:.03em}\
.guess-score{font-size:.65rem;letter-spacing:.12em;color:rgba(180,130,60,.4);text-transform:uppercase;white-space:nowrap}\
.tax-row{display:grid;grid-template-columns:repeat(2,1fr);gap:5px}\
.tax-badge{border-radius:2px;padding:5px 7px;text-align:center}\
.tax-badge.match{background:var(--match-bg);border:1px solid var(--match-border)}\
.tax-badge.close{background:var(--close-bg);border:1px solid var(--close-border)}\
.tax-badge.miss{background:var(--miss-bg);border:1px solid var(--miss-border)}\
.tax-lbl{font-size:.56rem;letter-spacing:.16em;text-transform:uppercase;margin-bottom:2px}\
.tax-badge.match .tax-lbl{color:var(--match-label)}\
.tax-badge.close .tax-lbl{color:var(--close-label)}\
.tax-badge.miss  .tax-lbl{color:var(--miss-label)}\
.tax-val{font-size:.74rem;line-height:1.2}\
.tax-badge.match .tax-val{color:var(--match-text)}\
.tax-badge.close .tax-val{color:var(--close-text)}\
.tax-badge.miss  .tax-val{color:var(--miss-text)}\
.tax-dir{font-size:.62rem;margin-top:1px;opacity:.6}\
@media(max-width:620px){\
  .game-columns{grid-template-columns:1fr;padding:0 12px}\
  .left-col{padding-right:0;border-right:none;border-bottom:1px solid rgba(180,130,60,.1);padding-bottom:16px;margin-bottom:16px}\
  .right-col{padding-left:0;max-height:none}\
  .title{font-size:1.9rem}\
  .era-modal{padding:20px}\
}\
';

function StyleTag() {
  useEffect(function() {
    var el = document.createElement("style");
    el.textContent = CSS;
    document.head.appendChild(el);
    return function() { document.head.removeChild(el); };
  }, []);
  return null;
}

function BgScroll() {
  var names = TERMS.map(function(t) { return t.name; });
  var doubled = names.concat(names);
  return (
    <div className="bg-scroll">
      {[0,1,2,3,4].map(function(i) {
        return (
          <div key={i} className="bg-col">
            {doubled.map(function(name, j) {
              return <div key={j} className="bg-term">{name}</div>;
            })}
          </div>
        );
      })}
    </div>
  );
}

function EraModal(props) {
  var era = props.era;
  var onClose = props.onClose;
  var data = ERA_SUMMARIES[era];
  if (!data) return null;

  useEffect(function() {
    function onKey(e) { if (e.key === "Escape") onClose(); }
    document.addEventListener("keydown", onKey);
    return function() { document.removeEventListener("keydown", onKey); };
  }, []);

  return (
    <div className="era-modal-overlay" onClick={onClose}>
      <div className="era-modal" onClick={function(e){ e.stopPropagation(); }}>
        <button className="era-close" onClick={onClose}>✕ Close</button>
        <div className="era-title">{era}</div>
        <div className="era-dates">{data.dates}</div>
        <div className="era-divider" />
        <div className="era-overview">{data.overview}</div>
        <div className="era-divider" />
        <div className="era-section-label">Key Themes</div>
        <div className="era-themes">
          {data.keyThemes.map(function(t, i){
            return <div key={i} className="era-theme">{t}</div>;
          })}
        </div>
        <div className="era-section-label">Key Figures</div>
        <div className="era-figures">
          {data.keyFigures.map(function(f, i){
            return <div key={i} className="era-figure">{f}</div>;
          })}
        </div>
        <div className="era-exam">
          <div className="era-exam-label">IB Exam Tip</div>
          <div className="era-exam-text">{data.examTip}</div>
        </div>
      </div>
    </div>
  );
}

var LEVELS = ["period","type","actor","impact"];
var LEVEL_LABELS = {period:"Period",type:"Type",actor:"Actor",impact:"Impact"};

function Ottoman() {
  var modeState = useState("solo");
  var mode = modeState[0], setMode = modeState[1];
  var targetState = useState(function(){ return getRandomTerm(null); });
  var target = targetState[0], setTarget = targetState[1];
  var guessesState = useState([]);
  var guesses = guessesState[0], setGuesses = guessesState[1];
  var inputState = useState("");
  var input = inputState[0], setInput = inputState[1];
  var dropState = useState(false);
  var showDrop = dropState[0], setShowDrop = dropState[1];
  var wonState = useState(false);
  var won = wonState[0], setWon = wonState[1];
  var hintState = useState(0);
  var hint = hintState[0], setHint = hintState[1];
  var eraState = useState(null);
  var selectedEra = eraState[0], setSelectedEra = eraState[1];
  var dropRef = useRef(null);

  function newGame() {
    setTarget(getRandomTerm(target.name));
    setGuesses([]);
    setInput("");
    setShowDrop(false);
    setWon(false);
    setHint(0);
  }

  var guessedNames = useMemo(function() {
    return new Set(guesses.map(function(g) { return g.name; }));
  }, [guesses]);

  var suggestions = useMemo(function() {
    if (!input.trim()) return [];
    var q = input.toLowerCase();
    return TERMS.filter(function(t) {
      return !guessedNames.has(t.name) && t.name.toLowerCase().indexOf(q) !== -1;
    }).slice(0, 7);
  }, [input, guessedNames]);

  function submit(term) {
    var c = compare(term, target);
    setGuesses(function(p) { return [Object.assign({}, term, {comparison:c})].concat(p); });
    setInput("");
    setShowDrop(false);
    if (term.name === target.name) setWon(true);
  }

  function onKey(e) {
    if (e.key === "Enter" && suggestions.length > 0) submit(suggestions[0]);
    if (e.key === "Escape") setShowDrop(false);
  }

  useEffect(function() {
    function out(e) {
      if (dropRef.current && !dropRef.current.contains(e.target)) setShowDrop(false);
    }
    document.addEventListener("mousedown", out);
    return function() { document.removeEventListener("mousedown", out); };
  }, []);

  var hintThresh = mode === "class" ? 0 : mode === "group" ? 2 : 4;
  var maxHints = mode === "solo" ? 2 : 1;
  var canHint = !won && guesses.length >= hintThresh && hint < maxHints;
  var litDots = Math.min(guesses.length, 10);
  var totalDots = Math.min(target.name.replace(/\s/g,"").length, 12);
  var wrongGuesses = guesses.filter(function(g){ return g.name !== target.name; });

  return (
    <div className="wrap">
      <StyleTag />
      <BgScroll />

      {selectedEra && (
        <EraModal era={selectedEra} onClose={function(){ setSelectedEra(null); }} />
      )}

      <header className="header">
        <div className="hline top" />
        <div className="title">CLIO</div>
        <div className="subtitle">The Ottoman Empire · Unit I</div>
        <div className="unit-tag">c1800 – 1923 · {TERMS.length} Terms</div>
        <div className="hline bot" />
      </header>

      <div className="top-bar">
        {[["solo","Solo"],["class","Class"],["group","Small Group"]].map(function(pair) {
          return (
            <button key={pair[0]} className={"mode-btn"+(mode===pair[0]?" active":"")}
              onClick={function(){ setMode(pair[0]); }}>{pair[1]}</button>
          );
        })}
        <button className="new-btn" onClick={newGame}>↺ New Term</button>
      </div>

      <div className="period-bar">
        {PERIOD_ORDER.map(function(p){
          return (
            <div key={p}
              className={"pl-item"+(selectedEra===p?" era-active":"")}
              onClick={function(){ setSelectedEra(selectedEra===p?null:p); }}
              title="Click for era summary">
              {p}
            </div>
          );
        })}
      </div>

      <div className="mystery-area">
        <div className="mystery-label">Mystery Term</div>
        {won ? (
          <div>
            <div className="mystery-solved">{target.name}</div>
            <div className="mystery-def">{target.definition}</div>
          </div>
        ) : (
          <div className="mystery-box">
            {Array.from({length:totalDots}).map(function(_,i){
              return <div key={i} className={"mystery-dot"+(i<litDots?" lit":"")} />;
            })}
          </div>
        )}
        <div className="guess-counter">
          {won
            ? "Solved in "+guesses.length+(guesses.length===1?" guess":" guesses")
            : guesses.length+" guess"+(guesses.length!==1?"es":"")+" · "+(TERMS.length-guessedNames.size)+" terms remaining"}
        </div>
      </div>

      {won && (
        <div className="win-banner">
          <div className="win-text">✦ Correct ✦</div>
          <div className="win-sub">{target.period} · {target.type} · {target.actor}</div>
          <div><button className="win-again" onClick={newGame}>Play Again — New Term</button></div>
        </div>
      )}

      {!won && mode !== "class" && (
        <div className="hint-area">
          <button className="hint-btn" onClick={function(){setHint(function(h){return h+1;});}} disabled={!canHint}>
            {hint===0
              ? "Reveal Hint"+(hintThresh>0?" (after "+hintThresh+" guesses)":"")
              : (hint===1&&mode==="solo")?"Reveal Definition":"—"}
          </button>
          {hint>=1 && <div className="hint-text">💡 {target.hint}</div>}
          {hint>=2 && mode==="solo" && <div className="hint-text" style={{marginTop:"5px",opacity:.65}}>{target.definition}</div>}
        </div>
      )}
      {!won && mode==="class" && guesses.length>0 && (
        <div className="hint-area">
          <div className="hint-text" style={{opacity:.4}}>Class note: This term is classified as {target.type}</div>
        </div>
      )}

      <div className="game-columns">
        <div className="left-col">
          <div className="col-label">Make a Guess</div>
          {!won && (
            <div className="search-wrap" ref={dropRef}>
              <div className="search-row">
                <input className="search-input" value={input}
                  onChange={function(e){setInput(e.target.value);setShowDrop(true);}}
                  onFocus={function(){setShowDrop(true);}}
                  onKeyDown={onKey}
                  placeholder="Type a term, person, treaty..." autoComplete="off" />
                <button className="guess-btn" disabled={suggestions.length===0}
                  onClick={function(){if(suggestions.length>0)submit(suggestions[0]);}}>Guess</button>
              </div>
              {showDrop && suggestions.length>0 && (
                <div className="dropdown">
                  {suggestions.map(function(t){
                    return (
                      <div key={t.name} className="drop-item" onClick={function(){submit(t);}}>
                        <div className="drop-name">{t.name}</div>
                        <div className="drop-meta">{t.period} · {t.type} · {t.actor}</div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
          {won && (
            <div style={{fontStyle:"italic",color:"rgba(180,130,60,.4)",fontSize:".88rem",marginTop:"8px"}}>
              Term identified. Start a new round above.
            </div>
          )}
          <div className="legend" style={{marginTop:"16px"}}>
            <div className="leg-item"><div className="leg-dot match"/>Exact Match</div>
            <div className="leg-item"><div className="leg-dot close"/>Close</div>
            <div className="leg-item"><div className="leg-dot miss"/>Miss</div>
          </div>
          <div style={{marginTop:"16px",fontSize:".68rem",color:"rgba(180,130,60,.3)",letterSpacing:".1em",textTransform:"uppercase"}}>
            Tip: click an era above for a summary
          </div>
        </div>

        <div className="right-col">
          <div className="col-label">Previous Guesses {wrongGuesses.length>0?"("+wrongGuesses.length+")":""}</div>
          {wrongGuesses.length===0 && (
            <div className="no-guesses">No guesses yet — start typing on the left.</div>
          )}
          {wrongGuesses.map(function(g,i){
            var score = matchScore(g.comparison);
            return (
              <div key={g.name+"-"+i} className="guess-card">
                <div className="guess-top">
                  <span className="guess-name">{g.name}</span>
                  <span className="guess-score">{score}/4</span>
                </div>
                <div className="tax-row">
                  {LEVELS.map(function(lvl){
                    var cell = g.comparison[lvl];
                    return (
                      <div key={lvl} className={"tax-badge "+cell.result}>
                        <div className="tax-lbl">{LEVEL_LABELS[lvl]}</div>
                        <div className="tax-val">{cell.label}</div>
                        {cell.dir && <div className="tax-dir">{cell.dir}</div>}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

ReactDOM.render(React.createElement(Ottoman, null), document.getElementById('root'));